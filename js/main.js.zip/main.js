
(function($) {
    var time = 0,
        timeDelta = 0,
        timeOutTimers = [],
        timerId = 0,
        refresh = function (price, time, timerId, $elem) {
            var format = price.toString();

            timeOutTimers[timerId] = setTimeout(function () {
                $elem.prop('totalPrice', price);
                format = format.replace(/(\d)(?=(\d{3})+(\D|$))/g, '$1 ');
                $elem.text(format);
            }, time);

            return timeOutTimers[timerId];
        };

    var options;

    $.fn.changeNumbers = function(options){
        options = $.extend({
            start: 0,
            end: 1
        }, options);

        var start = parseInt(options.start),
            end = parseInt(options.end);
        debugger;

        if (timeOutTimers.length) {
            for (var i = 0; i < timeOutTimers.length; i++) {
                clearTimeout(timeOutTimers[i]);
            }
        }

        for (start; end !== start;) {

            timeDelta = 1000 / Math.abs(end - start);

            if (end > start) {
                start++;
                refresh(start, time, timerId, this);

            }

            if (end < start) {
                start--;
                refresh(start, time, timerId, this);
            }

            timerId++;
            time += (timeDelta * 0.25);
        }
    };
})(jQuery);

$(document).ready(function () {

    $('h1').on('click', function (e) {
        e.preventDefault();

        $('.num').changeNumbers({
            start: '1000',
            end: '5000'
        });
    });
});